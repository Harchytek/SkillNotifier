
## v1.2.0
Added a security, recalculated and corrected XP gains.

## v1.1.0
Fixes the percentage gain.

## v1.0.0
Initial release