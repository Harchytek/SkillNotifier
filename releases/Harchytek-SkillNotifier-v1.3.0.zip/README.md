# SkillNotifier

A highly customizable mod that displays real-time, clean, and color-coded XP notifications for your skills.

<p align="left"><img src="https://imgur.com/ED2duAb.png" alt="SkillNotifier" width="510"></p>

## Features

* **Auto-translate** : The skill names are translated into your game's language.
* **Notification Filtering** : Includes a built-in option to ignore "run" notifications.
* **Global Progression** : Optional display of your character's Total Level across all skills.
* **Highly configurable** : Full control over Visibility, Texts, Position, Symbols, and Colors.
##
### Default 

![Default](https://imgur.com/BHOy62y.png)

### Visibility

![Visibility](https://imgur.com/KLyY9LN.png)

### Text

![Text](https://imgur.com/jV7KMUK.png)

### Position

![Position](https://imgur.com/ZvJkmcf.png)

### Symbols

![Symbols](https://imgur.com/IX8PNdC.png)

### Colors

![Colors](https://imgur.com/stQieIG.png)

*Thanks Stegodon for the screenshots.*

## Installation
1. Install [BepInExPack Valheim](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/).
2. Place `SkillNotifier.dll` in your `BepInEx/plugins` folder.
3. Launch the game once to generate the config file.

## Configuration

Use a [Configuration Manager](https://thunderstore.io/c/valheim/p/Azumatt/Azus_UnOfficial_ConfigManager/) to
modify settings in-game.

![SkillNotifierMananger](https://imgur.com/WpQ1oBP.png)

## About myself

If you have any suggestions or need help, you can contact me on Github.

I make these mods for my friends and me, but they can be useful to everyone. It's my way of contributing to the Valheim community.

<p align="left"><img src="https://raw.githubusercontent.com/Harchytek/HudStar/main/docs/images/github.png" alt="SkillNotifier" width="50"><strong><a href="https://github.com/Harchytek?tab=repositories">Harchytek</a></strong></p>